<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="20"/>
        <source>MX Boot Repair</source>
        <translation>MX Boot-Reparatur</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="39"/>
        <source>MX Boot Repair is a utility that can be used to reinstall GRUB bootloader on the ESP (EFI System Partition), MBR (Master Boot Record) or root partition. It provides the option to reconstruct the GRUB configuration file and to back up and restore MBR or PBR (root).</source>
        <translation>Die Bootreparatur ist ein Werkzeug zur nochmaligen Installation des GRUB Bootprogramms auf die ESP (EFI System Partition), den MBR (Master Boot Record) oder die Wurzelpartition. Das Werkzeug bietet die Möglichkeit, die GRUB Konfigurationsdatei zu rekonstruieren und den MBR oder PBR (root) zu sichern oder aus einer Sicherung wiederherzustellen. </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="58"/>
        <source>What would you like to do?</source>
        <translation>Was wollen sie tun?</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="79"/>
        <source>Backup MBR or PBR (legacy boot only)</source>
        <translation>MBR oder PBR sichern (nur Legacy-Boot)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="86"/>
        <source>Reinstall GRUB bootloader on ESP, MBR or PBR (root)</source>
        <translation>Nochmalige Installation des GRUB Bootprogramms in ESP, MBR oder PBR (root)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="96"/>
        <source>Repair GRUB configuration file</source>
        <translation>Die GRUB-Konfigurationsdatei reparieren</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="103"/>
        <source>Restore MBR or PBR from backup (legacy boot only)</source>
        <translation>MBR oder PBR aus Backup wieder herstellen (nur Legacy-Boot)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="136"/>
        <location filename="../mainwindow.cpp" line="564"/>
        <source>Select Boot Method</source>
        <translation>Boot-Methode auswählen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="154"/>
        <source>Master Boot Record</source>
        <translation>Master Boot Record</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="157"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <location filename="../mainwindow.ui" line="430"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="182"/>
        <source>Root (Partition Boot Record)</source>
        <translation>root (Bootsektor einer Partition)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="185"/>
        <location filename="../mainwindow.cpp" line="567"/>
        <source>root</source>
        <translation>root</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="236"/>
        <location filename="../mainwindow.cpp" line="566"/>
        <source>Install on:</source>
        <translation>Installiere auf:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="255"/>
        <location filename="../mainwindow.cpp" line="565"/>
        <source>Location:</source>
        <translation>Ort:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="277"/>
        <location filename="../mainwindow.cpp" line="575"/>
        <source>Select root location:</source>
        <translation>root-Speicherort auswählen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="290"/>
        <source>EFI System Partition</source>
        <translation>EFI-Systempartition</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="293"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="420"/>
        <source>About this application</source>
        <translation>Über diese Anwendung</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="423"/>
        <source>About...</source>
        <translation>Über...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="472"/>
        <source>Display help </source>
        <translation>Hilfe anzeigen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="475"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="482"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="523"/>
        <source>Cancel any changes then quit</source>
        <translation>Änderungen verwerfen, danach abbrechen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="526"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="533"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="552"/>
        <source>Apply any changes</source>
        <translation>Alle Änderungen übernehmen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="555"/>
        <location filename="../mainwindow.cpp" line="93"/>
        <source>Apply</source>
        <translation>Übernehmen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="109"/>
        <source>GRUB is being installed on %1 device.</source>
        <translation>GRUB wird auf Gerät %1 installiert.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="149"/>
        <location filename="../mainwindow.cpp" line="235"/>
        <location filename="../mainwindow.cpp" line="361"/>
        <location filename="../mainwindow.cpp" line="459"/>
        <location filename="../mainwindow.cpp" line="498"/>
        <location filename="../mainwindow.cpp" line="603"/>
        <location filename="../mainwindow.cpp" line="607"/>
        <location filename="../mainwindow.cpp" line="615"/>
        <location filename="../mainwindow.cpp" line="622"/>
        <location filename="../mainwindow.cpp" line="628"/>
        <location filename="../mainwindow.cpp" line="682"/>
        <location filename="../mainwindow.cpp" line="693"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="150"/>
        <location filename="../mainwindow.cpp" line="236"/>
        <source>Could not set up chroot environment.
Please double-check the selected location.</source>
        <translation>Die chroot-Umgebung konnte nicht eingerichtet werden.
Bitte nochmals den ausgewählten Ort prüfen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="215"/>
        <source>The GRUB configuration file (grub.cfg) is being rebuilt.</source>
        <translation>Die  GRUB-Konfigurationsdatei (grub.cfg) wird erneuert.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="253"/>
        <source>Backing up MBR or PBR from %1 device.</source>
        <translation>Der MBR oder PBR von Gerät %1 wird gesichert.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="333"/>
        <source>Warning</source>
        <translation>Warnung</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="334"/>
        <source>You are going to write the content of </source>
        <translation>Sie werden den Inhalt</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="334"/>
        <source> to </source>
        <translation>in diese Datei schreiben</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="335"/>
        <source>

Are you sure?</source>
        <translation>

Sind sie sicher?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="341"/>
        <source>Restoring MBR/PBR from backup to %1 device.</source>
        <translation>MBR/PBR wird aus der Sicherung wiederhergestellt auf Gerät %1.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="362"/>
        <source>Could not find EFI system partition (ESP) on any system disks. Please create an ESP and try again.</source>
        <translation>Konnte keine EFI-Systempartition (ESP) auf irgendeinem Laufwerk finden. Bitte erstellen sie eine ESP und versuchen sie es erneut.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="405"/>
        <source>Select %1 location:</source>
        <translation>%1 Ort auswählen :</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="436"/>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="453"/>
        <source>Success</source>
        <translation>Erfolg</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="453"/>
        <source>Process finished with success.&lt;p&gt;&lt;b&gt;Do you want to exit MX Boot Repair?&lt;/b&gt;</source>
        <translation>Prozess erfolgreich beendet. &lt;p&gt;&lt;b&gt;Die MX-Boot-Reparatur schliessen?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="459"/>
        <source>Process finished. Errors have occurred.</source>
        <translation>Prozess beendet.  Dabei sind Fehler aufgetreten.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="487"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Passwort eingeben um verschlüsselte Partition %1 freizugeben :</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="498"/>
        <source>Sorry, could not open %1 LUKS container</source>
        <translation>Der LUKS Container  %1 konnte nicht geöffnet werden. </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="574"/>
        <source>Select GRUB location</source>
        <translation>GRUB-Speicherort</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="586"/>
        <source>Select Item to Back Up</source>
        <translation>Eintrag zur Sicherung auswählen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="593"/>
        <source>Select Item to Restore</source>
        <translation>Eintrag zum Wiederherstellen auswählen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="603"/>
        <location filename="../mainwindow.cpp" line="628"/>
        <source>No location was selected.</source>
        <translation>Es wurde kein Speicherort ausgewählt.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="608"/>
        <source>Please select the root partition of the system you want to fix.</source>
        <translation>Bitte die root-Partition des Systems auswählen, das sie reparieren möchten.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="613"/>
        <source>Select backup file name</source>
        <translation>Den Backup-Dateinamen auswählen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="615"/>
        <location filename="../mainwindow.cpp" line="622"/>
        <source>No file was selected.</source>
        <translation>Es wurde keine Datei ausgewählt.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="620"/>
        <source>Select MBR or PBR backup file</source>
        <translation>Backup-Datei MBR oder PBR auswählen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="645"/>
        <source>About %1</source>
        <translation>Über %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="647"/>
        <source>Version: </source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="648"/>
        <source>Simple boot repair program for MX Linux</source>
        <translation>Einfaches Boot-Reparatur Program für MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="650"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="652"/>
        <source>%1 License</source>
        <translation>%1 Lizenz</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="665"/>
        <source>%1 Help</source>
        <translation>%1 Hilfe</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="682"/>
        <source>Sorry, could not mount %1 partition</source>
        <translation>Partition %1 konnte nicht eingebunden werden</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="693"/>
        <source>Could not create a temporary folder</source>
        <translation>Es konnte kein Temporärverzeichnis angelegt werden</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="51"/>
        <source>License</source>
        <translation>Lizenz</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="52"/>
        <location filename="../about.cpp" line="62"/>
        <source>Changelog</source>
        <translation>Änderungsprotokoll</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="53"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="72"/>
        <source>&amp;Close</source>
        <translation>&amp;Schließen</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="53"/>
        <source>MX Boot Repair</source>
        <translation>MX-Bootreparatur</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="86"/>
        <source>Error</source>
        <translation type="unfinished">Fehler</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="87"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
